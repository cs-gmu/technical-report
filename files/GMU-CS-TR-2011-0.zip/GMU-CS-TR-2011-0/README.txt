This directory contains three files which may prove of use to you:

template.tex			The LaTeX template file, which you can
				build off of to make your own technical
				report.

GMU-CS-TR-2011-0.bib		The bibliography entry for this paper,
				which you could use as a template for
				your own bibliography entry.

GMU-CS-TR-2011-0.tex 		The paper itself, which you could use
				as an example.
